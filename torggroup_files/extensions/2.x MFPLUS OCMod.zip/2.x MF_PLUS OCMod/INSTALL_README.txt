


      You should install Mega Filter PRO and Mega Filter PLUS
              
               because PLUS is an extension of PRO