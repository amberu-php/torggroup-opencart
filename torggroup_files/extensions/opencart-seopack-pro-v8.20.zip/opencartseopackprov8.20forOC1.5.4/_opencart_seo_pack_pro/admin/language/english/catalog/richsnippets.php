<?php
// Heading
$_['heading_title']    = 'Rich Snippets';

// Text 
$_['text_success']     = 'Success: You have saved Rich Snippets!';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Rich Snippets!';
?>