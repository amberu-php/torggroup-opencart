================================================================================
 Multi Language SEO URLs  v1.1                                        10th May 2012


[Description]
This extension helps you set multiple urls for every product/category/brand/info (one for each language).

[Compatibility]
Supports OpenCart Version 1.5.1.3 + (vqmod required)

Author:  OviFe21

================================================================================

--------------------------------------------------------------------------------
[Installation]
--------------------------------------------------------------------------------

		1. No files or data will be overridden
		2. Copy 'vqmod' folder in the root folder of your website
		3. Set multi-language titles and meta descriptions for your home page in admin area -> System -> Settings -> Edit your store -> Store tab.


--------------------------------------------------------------------------------
[Other]
--------------------------------------------------------------------------------
